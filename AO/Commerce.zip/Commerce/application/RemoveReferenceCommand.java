package application;

import domain.*;

public class RemoveReferenceCommand extends Command{
    private Reference ref;

    public RemoveReferenceCommand(Reference ref, Basket basket , BasketRepository repo){
        super(basket,repo);
        this.ref = ref;
        
    }


    public void execute(){
        System.out.println("Reference remove to the basket with ID : " + this.basket.getId() + " and Name : " + this.ref.getName());

        this.basket.removeReference(this.ref);
        this.repo.save(this.basket);
    }   
}
