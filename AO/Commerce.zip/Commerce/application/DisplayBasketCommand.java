package application;

import domain.*;
import java.util.Map;

public class DisplayBasketCommand extends Command{
    
    public DisplayBasketCommand(Basket basket , BasketRepository repo){
        super(basket,repo);
    }

    public void execute(){
        System.out.println("");
        for (Map.Entry el : this.basket.getCommandList().entrySet()) {
            System.out.println("ID: "+el.getKey()+", Nom: "+el.getValue());
       }
       System.out.println("");

    }

}