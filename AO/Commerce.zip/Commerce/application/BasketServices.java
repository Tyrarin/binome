package application;

import domain.*;
import infrastructure.*;
import java.util.Map;

public class BasketServices {
    BasketRepository repo;
    Basket cache;
    Worker work;
    
    public BasketServices(){
        this.repo = new BasketRepositoryJSONImpl();
        this.work = new Worker();
    }

    public int createBasket(){
        cache = new Basket();
        repo.save(cache);
        return cache.getId();
    }

    public void addReferenceToBasket(int id , Reference ref , int quantity){
        if(cache.getId() != id){
            cache = repo.load(id);
        }

        this.work.pushCommand(new AddReferenceCommand(ref,quantity,cache,repo));
    }

    public void removeReferenceToBasket(int id , Reference ref){
        if(cache.getId() != id){
            cache = repo.load(id);
        }

        this.work.pushCommand(new RemoveReferenceCommand(ref,cache,repo));
    }

    public void displayBasket(int id){
        if(cache.getId() != id){
            cache = repo.load(id);
        }

        this.work.pushCommand(new DisplayBasketCommand(cache,repo));
    }

}
