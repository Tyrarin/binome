package application;

import domain.*;
import java.util.LinkedList;
import java.util.Queue;

public class Worker extends Thread{
    Queue<Command> commandList;

    public Worker(){
        this.commandList = new LinkedList<>();
        this.start();    
    }



    public synchronized void pushCommand(Command c){
        commandList.add(c);

    }

    public synchronized  Command getCommand(){
        return commandList.remove();
    }

    public void run(){
        while(true){

            try {
                this.sleep(100); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if(this.commandList.size() > 0){
                getCommand().execute();
            }
        }
    }
}
