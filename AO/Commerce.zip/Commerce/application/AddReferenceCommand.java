package application;


import domain.*;

public class AddReferenceCommand extends Command{
    private int quantity;
    private Reference refer;

    public AddReferenceCommand(Reference ref , int qty , Basket basket , BasketRepository repo){
        super(basket,repo);
        this.quantity = qty;
        this.refer = ref;
    }

    public void execute(){
        //System.out.println("Reference add to the basket with ID : " + this.basket.getId() + " and Name : " + this.refer.getName());

        this.basket.addReference(this.refer,this.quantity);
        this.repo.save(this.basket);
    }
}
