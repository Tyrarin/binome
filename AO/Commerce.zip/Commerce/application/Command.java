package application;

import infrastructure.BasketRepositoryJSONImpl;

import domain.*;

public abstract class Command {
    protected BasketRepository repo;
    protected Basket basket;

    public Command(Basket b, BasketRepository repo){
        this.repo = repo;
        this.basket = b;
    }

    public abstract void execute();
}
