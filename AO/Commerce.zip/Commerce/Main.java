import domain.*;
import infrastructure.*;
import application.*;
import java.util.*;
import ui.CLI;

class Main {
    public static void main (String[] args){
        CLI ui = new CLI();
     }

 }
