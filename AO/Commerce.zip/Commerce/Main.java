
import domain.*;
import infrastructure.*;
import application.*;
import java.util.*;

class Main {
    public static void main (String[] args){

         Reference r1 = new Reference("first", "first", "bla", 1);
         Reference r2 = new Reference("firstss", "first", "bla", 1);
         Reference r3 = new Reference("Haricots", "Legumes", "Ehoui", 1);

         
         BasketServices basket = new BasketServices();
         int id = basket.createBasket();

         basket.addReferenceToBasket(id,r1,3);
         basket.addReferenceToBasket(id,r2,3);
         basket.addReferenceToBasket(id,r3,30);


         basket.displayBasket(id);
         basket.removeReferenceToBasket(id,r3);

            while(true){

            }
     }

 }
