#!/bin/sh

javac -cp lib/json-simple-1.1.jar -d classes domain/*.java infrastructure/*.java application/*.java ui/*.java Main.java
java -cp classes/:lib/json-simple-1.1.jar Main

