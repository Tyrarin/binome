package ui;

import application;

public class CLI {
    public CLI(){
        
    }
}
