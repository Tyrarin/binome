package ui;

import application.*;
import java.util.Scanner;
import domain.Reference;

public class CLI {
    private Scanner sc;
    private BasketServices basket;
    private int id;

    public CLI(){
        this.sc = new Scanner(System.in);
        this.basket = new BasketServices();
        startUI();
    }

    public void startUI(){
        System.out.println("Enter (1) if you want to create a new Basket, (2) if you want to load one");
        int ret = sc.nextInt();
        sc.nextLine();
        if(ret == 1){
            this.id = basket.createBasket();
            runUI();
        }
        else if(ret ==2){
            System.out.println("Enter the id of the Basket you want to load");
            this.id = sc.nextInt();
            sc.nextLine();
            if(!basket.loadBasket(this.id)){
                //throw new IllegalAccessException(("This ID don't exist"));
            }
            runUI();

        }
        else{
            System.out.println("You only need to enter (1) or (2)");
        }
    }

    public void runUI(){
        while(true){
            System.out.println("Enter (1) to add a product, (2) to delete, (3) to display the basket, (4) to restart ");
            int ret = sc.nextInt();
            sc.nextLine();
            if(ret == 1){
                System.out.println("Enter ID of your product");
                String id = sc.nextLine();

                System.out.println("Enter Name of your product");
                String name = sc.nextLine();

                System.out.println("Enter Description of your product");
                String description = sc.nextLine();

                System.out.println("Enter Price of your product");
                int price = sc.nextInt();
                sc.nextLine();

                System.out.println("Enter Quantity of your product");
                int quantity = sc.nextInt();
                sc.nextLine();

                Reference ref = new Reference(id,name,description,price);
                basket.addReferenceToBasket(this.id,ref,quantity);

            }
            else if(ret == 2){
                System.out.println("Enter ID of your product");
                String id = sc.nextLine();

                System.out.println("Enter Name of your product");
                String name = sc.nextLine();

                System.out.println("Enter Description of your product");
                String description = sc.nextLine();

                System.out.println("Enter Price of your product");
                int price = sc.nextInt();
                sc.nextLine();

                Reference ref = new Reference(id,name,description,price);
                basket.removeReferenceToBasket(this.id,ref);
            }
            else if(ret == 3){
                basket.displayBasket(this.id);
            }
            else if(ret == 4){
                startUI();
            }
            else{

            }
        }

    }
}

