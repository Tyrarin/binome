package infrastructure;
import java.util.HashSet;
import java.util.Set;
import domain.*;

public class BasketRepositoryMemImpl implements BasketRepository{
    private Set<Basket> basketList;

    BasketRepositoryMemImpl(){
        basketList = new HashSet<Basket>();
    }

    public void save(Basket basket){
        this.basketList.add(basket);
    }

    public Basket load(int id){
        for(Basket basket : this.basketList){
            if(basket.getId() == id)
                return basket;
        }
        return null;
    }
}
