package infrastructure;

import domain.*;

public class BasketRepositoryMemImpl implements BasketRepository{
    private Basket b;
    BasketRepositoryMemImpl(){

    }

    public void save(Basket basket){
        this.b = basket;
    }

    public Basket load(int id){
        return this.b;
    }
}
