#ifdef CHANGED

#include "syscall.h"

//This is a simple test program for the PutInt function of the Nachos project, which aims to write an integer passed as a parameter to PutInt (int n) on the console.
//The program is started using the command: ./nachos -x ../test/putint from the userprog / folder.
//This test file only contains different calls to PutInt with larger or smaller digits.
//We see that with too large numbers, the return does not work. This is due to the fact that the snprintf function 
//we use takes an int as a parameter which has a limit

int main (){
    PutInt(-56);
    PutInt (1);
    PutInt(123);
    PutInt(1234567890);
    PutInt(12345678901234567890); // Too big
    return 0;
}

#endif //CHANGED