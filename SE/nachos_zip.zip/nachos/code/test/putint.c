#include "syscall.h"
int main (){
    PutInt (1343);
    PutInt(123);
    return 0;
}