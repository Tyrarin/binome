#include "syscall.h"
int main (){
    int n = 100;
    char string[n];

    while(1){
         if(string[0] == 'q' && string[1] == '\n'){ //if q , stop the programm
            break;
        }

        GetString (string, n);
        PutString (string);
    }

    return 0;
}