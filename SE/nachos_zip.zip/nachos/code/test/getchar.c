#include "syscall.h"

int
main ()
{
    int ch;

    while (1){
	  ch = GetChar ();
	  PutChar ((char) ch);

      if((char) ch == 'q'){
          break;
      }
    }
    return 0;
}