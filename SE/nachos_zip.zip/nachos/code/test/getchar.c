#ifdef CHANGED
#include "syscall.h"

//This is a small test program for the GetChar function which retrieves the characters entered by the user and then displays them on the console. 
//This program is started using the command: ./nachos -x ../test/getchar from the userprog / folder. 
//This function only contains an infinite loop stop when writing the character q, which writes via PutChar the character retrieved by GetChar

int main ()
{
    int ch;
    while (1){
	  ch = GetChar ();  // 
	  PutChar ((char) ch);

      if((char) ch == 'q'){
          break;
      }
    }
    return 0;
}

#endif //CHANGED