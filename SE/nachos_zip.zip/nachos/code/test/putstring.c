#ifdef CHANGED

#include "syscall.h"
int
main ()
{
    // Test with a lower String than MAX_STRING_SIZE
    PutString ("abc\n");
    // Test with a bigger String than MAX_STRING_SIZE
    PutString ("abcdefghijklmnopqrstuvwxyz\n");
    // String that contain \0 and \n --> We can see that what is after , isn't displayed
    PutString ("abcdef\nghijklm\n\0nopqr");
    return 0;
}

#endif //CHANGED