#ifdef CHANGED
#include "copyright.h"
#include "system.h"
#include "consoledriver.h"
#include "synch.h"

static Semaphore *readAvail;
static Semaphore *writeDone;

static Semaphore *sGet;
static Semaphore *sPut;

static void ReadAvailHandler(void *arg) { (void) arg; readAvail->V(); }
static void WriteDoneHandler(void *arg) { (void) arg; writeDone->V(); }

ConsoleDriver::ConsoleDriver(const char *in, const char *out)
{
    readAvail = new Semaphore("read avail", 0);
    writeDone = new Semaphore("write done", 0);

    sPut = new Semaphore ("putChar", 1);
    sGet = new Semaphore ("getChar", 1);

    #ifdef CHANGED
    console = new Console (in, out, ReadAvailHandler, WriteDoneHandler, NULL);
    #endif //CHANGED
}

ConsoleDriver::~ConsoleDriver()
{
    delete console;
    delete writeDone;
    delete readAvail;
}

void ConsoleDriver::PutChar(int ch)
{
    #ifdef CHANGED
    sPut->P (); //Puts the current process on hold, while the char is writing
    console->TX (ch);
    writeDone->P (); // wait for write to finish
    sPut->V (); //Make the resource available
    #endif //CHANGED
}

int ConsoleDriver::GetChar()
{
    #ifdef CHANGED
    sGet->P(); //Puts the current process on hold, while the char is reading
    readAvail->P ();		// wait for character to arrive
    int ch = (int) console->RX ();
    sGet->V (); //Make the resource available
    return ch;
    #endif //CHANGED
}

void ConsoleDriver::PutString(const char s[])
{
    #ifdef CHANGED
    int j = 0;
    while (s[j] != '\0')
    {
	  PutChar(s[j]);
	  j++;
    }
    #endif //CHANGED
}

void ConsoleDriver::GetString(char *s, int n)
{
    int result, j = 0;
    while ((j < n) && (result = GetChar ()) && ((char) result != '\0') && ((char) result != EOF) && ((char) result != '\n')){
        sGet->P();
	    s[j] = (char) result;
	    j++;
        sGet->V();
    }
    s[j] = '\n';
    s[j+1] = '\0';
}

void ConsoleDriver::PutInt (int n){
    char *result = new char[MAX_STRING_SIZE];
    snprintf(result, MAX_STRING_SIZE, "%d", n);
    PutString(result);
    PutChar('\n');
    delete []result;
}



#endif // CHANGED