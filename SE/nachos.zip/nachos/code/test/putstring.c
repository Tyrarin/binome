#ifdef CHANGED

#include "syscall.h"

//This is a test program for the requested PutString function, aimed at testing various calls to PutString with "stress" situations for the machine.
//This program is started using the command: ./nachos -x ../test/putstring from the userprog / folder.
//The situations tested are respectively with a string smaller than our constant, a string larger than our constant, 
//a string containing end of line characters '\ 0' supposed to stop writing and finally a situation with newlines .

int main (){
    // Test with a lower String than MAX_STRING_SIZE
    PutString ("abc\n");

    // Test with a bigger String than MAX_STRING_SIZE
    PutString ("abcdefghijklmnopqrstuvwxyz\n");

    // Test with String that contain \0 --> We can see that what is after , isn't displayed
    PutString ("gtrfhiefjierjfierjifjero\n\0frheuezhudhzeidiez\0xz");
    
    // Test with newlines to see that it works.
    PutString("abcd\nefg\nhij\n");

    return 0;
}

#endif //CHANGED