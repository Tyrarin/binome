#ifdef CHANGED
#include "syscall.h"

// This is a small test program for the GetString function which retrieves the characters entered by the user and then displays them on the console. 
// This program is started using the command: ./nachos -x ../test/getstring from the userprog / folder.
// This test file contains a while loop which loops endlessly until it hits the character q alone. 
// The loop is useful to be able to write a string greater than the size n given in the function, 
// and to be able to enter several character strings without having to restart the program.


int main (){
    int size = 50;
    char string[size];

    while(1){
         if(string[0] == 'q' && string[1] == '\n'){ //if q , stop the programm
            break;
        }
        GetString(string, size);
        PutString(string);
    }

    return 0;
}
#endif //CHANGED